from displayInterface import CrcCalculator, SerialCommands
# This needs to be the port that the USB is connected to on the PC
port_num = "COM6"

_Brightness_Events = {
    "OFF": 0,
    "LOW": 33,
    "MED": 66,
    "HIGH": 100
}


def clear_screen():
    crc = CrcCalculator()
    data = crc.append_crc([0x06, 0x00])
    SerialCommands(port=port_num).write_cmd(cmd=data)


def back_light_set(bright_input):
    crc = CrcCalculator()
    brightness = _Brightness_Events.get(bright_input)
    data = crc.append_crc([0x0E, 1, brightness])
    SerialCommands(port=port_num).write_cmd(cmd=data)