import displayCommands, time

displayCommands.clear_screen()
time.sleep(1)
# Display brightness can be ( OFF, LOW, MED, or HIGH )
display_brightness = "OFF"
displayCommands.back_light_set(display_brightness)