import serial
import threading
import Queue
import time

testPort = 'COM6'

class SerialPort(threading.Thread):
    def __init__(self, port_name=testPort, bit_rate=115200):
        super(SerialPort, self).__init__()
        print "Opening ", port_name
        self.s = serial.Serial(port_name, baudrate=bit_rate, timeout=0.02, interCharTimeout=0.05, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS, xonxoff=False, rtscts=False)
        self.rxQ = Queue.Queue()
            
    def write(self, txstuff):
        self.s.write(txstuff)
        
    def run(self):
        print "Starting SerialPort"
        if not self.s.isOpen():
            self.s.open()
        while True:
            try:
                sRX = self.s.read(128)
                if len(sRX) > 0:
                    self.rxQ.put(sRX)
            except (KeyboardInterrupt, SystemExit):
                print "Keyboard exception in serialQueue"
                raise
        
if __name__ == '__main__':
    sp = SerialPort(testPort)
    sp.start()
    while True:
        if sp.rxQ.qsize() > 0:
            print "Queue length %d" % (sp.rxQ.qsize())
            while sp.rxQ.qsize() > 0:
                serStuff = sp.rxQ.get()
        time.sleep(2)
